﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SofSys_Project_2
{
    /// <summary>
    /// It's a random variable.
    /// Public static random number generator, so that everything in the 
    /// application runs off of a single random number sequence.
    /// Check out aDeckOfCards.cs for the implementation of it in this project.
    /// </summary>
    public class aRandomVariable
    {
        public static Random rando;
    }
}
