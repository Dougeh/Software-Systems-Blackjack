﻿using System;
using System.Collections.Generic;
using System.Text;

public enum Suit
{   //An enumerator for card suits, could've used an int but this looks nicer
    SPADES,
    HEARTS,
    DIAMONDS,
    CLUBS
}

//K = 11
//Q = 12
//J = 13

namespace SofSys_Project_2
{
    /// <summary>
    /// aCard, a class representing a single playing card.  Has a suit and a value.
    /// </summary>
    public class aCard
    {
        public Suit suit;
        public int value;

        /// <summary>
        /// Parameterized constructor for aCard, takes in a suit and the value of the card 
        /// (K, Q, J being 11, 12, and 13 respectively, and A being 1, which can be made to be 11.
        /// </summary>
        /// <param name="s"></param>
        /// Suit s, the suit of the card
        /// <param name="v"></param>
        /// int v, the value of the card
        public aCard(Suit s, int v)    
        {
            this.suit = s;
            this.value = v;
        }
    }
}
