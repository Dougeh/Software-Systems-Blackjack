﻿//Douglas Wilklow
//Software Systems Development, Fall 2021 - Prof. Jeanty
//Form_Blackjack.cs
//For details, check the comments starting at line 16.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SofSys_Project_2
{
    /// <summary>
    /// 
    /// </summary>
    public partial class Form_Interview : Form
    {
        public static int main_cash;
        public static int main_seed;
        public static int main_numdecks;
        public static bool H17 = true;
        public Form_Interview()
        {
            InitializeComponent();
        }

        private void button_start_Click(object sender, EventArgs e)
        {
            //You've gotta select a number of decks to use
            if (this.comboBox_decks.SelectedItem == null)    //As long as it's not empty
            {
                MessageBox.Show("Error:  No value selected from drop-down list for Decks.\nPlease select a value to continue.", "Drop-down list error");
                return;
            }

            //Since this form is supposed to allow multiple Blackjack sessions to be started at once,
            //  this form is pretty much not allowed to do any heavy lifting itself.  The bulk of the code is in Form_Blackjack.
            aShoe shoe = new aShoe();
            Form_Blackjack frm = new Form_Blackjack();
            frm.Show();
        }

        private void radioButton_H17_CheckedChanged(object sender, EventArgs e)
        {
            H17 = true;
        }
        private void radioButton_S17_CheckedChanged(object sender, EventArgs e)
        {
            H17 = false;
        }

        private void Form_Interview_Load(object sender, EventArgs e)
        {
            main_cash = 100;
            main_seed = 999;
            main_numdecks = 0;
            H17 = false;
        }

        private void textBox_available_TextChanged(object sender, EventArgs e)
        {
            //Makes sure the user's not pulling any funny business.
            int x;
            bool is_num = int.TryParse(this.textBox_available.Text, out x); //Makes sure that it's an integer
            if (is_num)     //As long as the user's input is actually a number
                main_cash = x;  //Assigns the value to the appropriate variable.
            
            //I disabled the fun error messages out of fear of losing points due to it looking like a runtime error.
            
            //else            //If the user's up to no good, and is entering non-integers:
            //    MessageBox.Show("Nice try, pal:\nI see you've put some non-integer characters into the textbox.\nPlease only fill this textbox with numbers.");
        }

        private void textBox_seed_TextChanged(object sender, EventArgs e)
        {
            //Also copy-pasted from textBox_available's implementation, refer to that for detailed comments
            int x;
            bool is_num = int.TryParse(this.textBox_seed.Text, out x); //Makes sure that it's an integer
            if (is_num)
                main_seed = x;
            //else
            //    MessageBox.Show("Nice try, pal:\nI see you've put some non-integer characters into the textbox.\nPlease only fill this textbox with numbers.");

        }

        private void comboBox_decks_SelectedIndexChanged(object sender, EventArgs e)
        {
            int x; //Same parse I do for everything, this one's kind of unnecessary
            bool is_num = int.TryParse(this.comboBox_decks.SelectedItem.ToString(), out x);
            if (is_num)
                main_numdecks = x;
        }
    }
}
