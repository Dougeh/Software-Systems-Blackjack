﻿
namespace SofSys_Project_2
{
    partial class Form_Blackjack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Blackjack));
            this.label_blabber = new System.Windows.Forms.Label();
            this.label_bet = new System.Windows.Forms.Label();
            this.label_cash = new System.Windows.Forms.Label();
            this.button_hit = new System.Windows.Forms.Button();
            this.button_stand = new System.Windows.Forms.Button();
            this.textBox_resetSeed = new System.Windows.Forms.TextBox();
            this.button_reset = new System.Windows.Forms.Button();
            this.label_newSeed2 = new System.Windows.Forms.Label();
            this.label_newSeed1 = new System.Windows.Forms.Label();
            this.label_yourTotal = new System.Windows.Forms.Label();
            this.label_dealerTotal = new System.Windows.Forms.Label();
            this.textBox_newBet = new System.Windows.Forms.TextBox();
            this.label_yourTotal2 = new System.Windows.Forms.Label();
            this.label_dealer2 = new System.Windows.Forms.Label();
            this.button_newBet = new System.Windows.Forms.Button();
            this.pictureBox_Rat = new System.Windows.Forms.PictureBox();
            this.label_winLoseDraw = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Rat)).BeginInit();
            this.SuspendLayout();
            // 
            // label_blabber
            // 
            this.label_blabber.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label_blabber.BackColor = System.Drawing.Color.Transparent;
            this.label_blabber.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label_blabber.Location = new System.Drawing.Point(12, 193);
            this.label_blabber.Name = "label_blabber";
            this.label_blabber.Size = new System.Drawing.Size(660, 65);
            this.label_blabber.TabIndex = 1;
            this.label_blabber.Text = "stuff happens here (placeholder)";
            this.label_blabber.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label_bet
            // 
            this.label_bet.AutoSize = true;
            this.label_bet.BackColor = System.Drawing.Color.Transparent;
            this.label_bet.Location = new System.Drawing.Point(131, 261);
            this.label_bet.Name = "label_bet";
            this.label_bet.Size = new System.Drawing.Size(70, 15);
            this.label_bet.TabIndex = 3;
            this.label_bet.Text = "Current bet:";
            // 
            // label_cash
            // 
            this.label_cash.AutoSize = true;
            this.label_cash.BackColor = System.Drawing.Color.Transparent;
            this.label_cash.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label_cash.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label_cash.Location = new System.Drawing.Point(443, 257);
            this.label_cash.Name = "label_cash";
            this.label_cash.Size = new System.Drawing.Size(208, 28);
            this.label_cash.TabIndex = 4;
            this.label_cash.Text = "Total $ remaining: XXX";
            this.label_cash.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // button_hit
            // 
            this.button_hit.Location = new System.Drawing.Point(248, 244);
            this.button_hit.Name = "button_hit";
            this.button_hit.Size = new System.Drawing.Size(88, 35);
            this.button_hit.TabIndex = 6;
            this.button_hit.Text = "Hit";
            this.button_hit.UseVisualStyleBackColor = true;
            this.button_hit.Click += new System.EventHandler(this.button_hit_Click);
            // 
            // button_stand
            // 
            this.button_stand.Location = new System.Drawing.Point(358, 244);
            this.button_stand.Name = "button_stand";
            this.button_stand.Size = new System.Drawing.Size(88, 35);
            this.button_stand.TabIndex = 7;
            this.button_stand.Text = "Stand";
            this.button_stand.UseVisualStyleBackColor = true;
            this.button_stand.Click += new System.EventHandler(this.button_stand_Click);
            // 
            // textBox_resetSeed
            // 
            this.textBox_resetSeed.Location = new System.Drawing.Point(1, 383);
            this.textBox_resetSeed.Name = "textBox_resetSeed";
            this.textBox_resetSeed.Size = new System.Drawing.Size(68, 23);
            this.textBox_resetSeed.TabIndex = 8;
            this.textBox_resetSeed.Click += new System.EventHandler(this.textBox_resetSeed_Click);
            this.textBox_resetSeed.TextChanged += new System.EventHandler(this.textBox_resetSeed_TextChanged);
            // 
            // button_reset
            // 
            this.button_reset.Location = new System.Drawing.Point(0, 405);
            this.button_reset.Name = "button_reset";
            this.button_reset.Size = new System.Drawing.Size(69, 56);
            this.button_reset.TabIndex = 9;
            this.button_reset.Text = "Reset Random Elements";
            this.button_reset.UseVisualStyleBackColor = true;
            this.button_reset.Click += new System.EventHandler(this.button_reset_Click);
            // 
            // label_newSeed2
            // 
            this.label_newSeed2.AutoSize = true;
            this.label_newSeed2.BackColor = System.Drawing.Color.Transparent;
            this.label_newSeed2.Location = new System.Drawing.Point(0, 368);
            this.label_newSeed2.Name = "label_newSeed2";
            this.label_newSeed2.Size = new System.Drawing.Size(70, 15);
            this.label_newSeed2.TabIndex = 10;
            this.label_newSeed2.Text = "a new seed?";
            // 
            // label_newSeed1
            // 
            this.label_newSeed1.AutoSize = true;
            this.label_newSeed1.BackColor = System.Drawing.Color.Transparent;
            this.label_newSeed1.Location = new System.Drawing.Point(-2, 354);
            this.label_newSeed1.Name = "label_newSeed1";
            this.label_newSeed1.Size = new System.Drawing.Size(79, 15);
            this.label_newSeed1.TabIndex = 11;
            this.label_newSeed1.Text = "Hey kid, want";
            // 
            // label_yourTotal
            // 
            this.label_yourTotal.AutoSize = true;
            this.label_yourTotal.BackColor = System.Drawing.Color.Transparent;
            this.label_yourTotal.Font = new System.Drawing.Font("Segoe UI", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label_yourTotal.Location = new System.Drawing.Point(328, 430);
            this.label_yourTotal.Name = "label_yourTotal";
            this.label_yourTotal.Size = new System.Drawing.Size(43, 36);
            this.label_yourTotal.TabIndex = 12;
            this.label_yourTotal.Text = "77";
            this.label_yourTotal.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label_yourTotal.Visible = false;
            // 
            // label_dealerTotal
            // 
            this.label_dealerTotal.AutoSize = true;
            this.label_dealerTotal.BackColor = System.Drawing.Color.Transparent;
            this.label_dealerTotal.Font = new System.Drawing.Font("Segoe UI", 19F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label_dealerTotal.Location = new System.Drawing.Point(328, 157);
            this.label_dealerTotal.Name = "label_dealerTotal";
            this.label_dealerTotal.Size = new System.Drawing.Size(43, 36);
            this.label_dealerTotal.TabIndex = 13;
            this.label_dealerTotal.Text = "77";
            this.label_dealerTotal.Visible = false;
            // 
            // textBox_newBet
            // 
            this.textBox_newBet.Location = new System.Drawing.Point(199, 254);
            this.textBox_newBet.Name = "textBox_newBet";
            this.textBox_newBet.Size = new System.Drawing.Size(43, 23);
            this.textBox_newBet.TabIndex = 14;
            // 
            // label_yourTotal2
            // 
            this.label_yourTotal2.AutoSize = true;
            this.label_yourTotal2.BackColor = System.Drawing.Color.Transparent;
            this.label_yourTotal2.Location = new System.Drawing.Point(265, 434);
            this.label_yourTotal2.Name = "label_yourTotal2";
            this.label_yourTotal2.Size = new System.Drawing.Size(66, 15);
            this.label_yourTotal2.TabIndex = 15;
            this.label_yourTotal2.Text = "Hand total:";
            this.label_yourTotal2.Visible = false;
            // 
            // label_dealer2
            // 
            this.label_dealer2.AutoSize = true;
            this.label_dealer2.BackColor = System.Drawing.Color.Transparent;
            this.label_dealer2.Location = new System.Drawing.Point(261, 160);
            this.label_dealer2.Name = "label_dealer2";
            this.label_dealer2.Size = new System.Drawing.Size(70, 15);
            this.label_dealer2.TabIndex = 16;
            this.label_dealer2.Text = "Dealer total:";
            this.label_dealer2.Visible = false;
            // 
            // button_newBet
            // 
            this.button_newBet.Location = new System.Drawing.Point(248, 244);
            this.button_newBet.Name = "button_newBet";
            this.button_newBet.Size = new System.Drawing.Size(198, 35);
            this.button_newBet.TabIndex = 17;
            this.button_newBet.Text = "New Bet";
            this.button_newBet.UseVisualStyleBackColor = true;
            this.button_newBet.Click += new System.EventHandler(this.button_newBet_Click);
            // 
            // pictureBox_Rat
            // 
            this.pictureBox_Rat.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Rat.Image")));
            this.pictureBox_Rat.Location = new System.Drawing.Point(-13, 296);
            this.pictureBox_Rat.Name = "pictureBox_Rat";
            this.pictureBox_Rat.Size = new System.Drawing.Size(74, 61);
            this.pictureBox_Rat.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Rat.TabIndex = 18;
            this.pictureBox_Rat.TabStop = false;
            this.pictureBox_Rat.Visible = false;
            // 
            // label_winLoseDraw
            // 
            this.label_winLoseDraw.AutoSize = true;
            this.label_winLoseDraw.BackColor = System.Drawing.Color.Transparent;
            this.label_winLoseDraw.Font = new System.Drawing.Font("Stencil", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point);
            this.label_winLoseDraw.Location = new System.Drawing.Point(531, 240);
            this.label_winLoseDraw.Name = "label_winLoseDraw";
            this.label_winLoseDraw.Size = new System.Drawing.Size(85, 25);
            this.label_winLoseDraw.TabIndex = 19;
            this.label_winLoseDraw.Text = "label1";
            this.label_winLoseDraw.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_winLoseDraw.Visible = false;
            // 
            // Form_Blackjack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.ForestGreen;
            this.ClientSize = new System.Drawing.Size(684, 461);
            this.Controls.Add(this.label_winLoseDraw);
            this.Controls.Add(this.pictureBox_Rat);
            this.Controls.Add(this.button_newBet);
            this.Controls.Add(this.label_dealer2);
            this.Controls.Add(this.label_yourTotal2);
            this.Controls.Add(this.textBox_newBet);
            this.Controls.Add(this.label_newSeed1);
            this.Controls.Add(this.button_reset);
            this.Controls.Add(this.textBox_resetSeed);
            this.Controls.Add(this.button_stand);
            this.Controls.Add(this.button_hit);
            this.Controls.Add(this.label_cash);
            this.Controls.Add(this.label_bet);
            this.Controls.Add(this.label_blabber);
            this.Controls.Add(this.label_newSeed2);
            this.Controls.Add(this.label_dealerTotal);
            this.Controls.Add(this.label_yourTotal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form_Blackjack";
            this.Text = "Blackjack!";
            this.Load += new System.EventHandler(this.Form_Blackjack_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Rat)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_blabber;
        private System.Windows.Forms.Label label_bet;
        private System.Windows.Forms.Label label_cash;
        private System.Windows.Forms.Button button_hit;
        private System.Windows.Forms.Button button_stand;
        private System.Windows.Forms.TextBox textBox_resetSeed;
        private System.Windows.Forms.Button button_reset;
        private System.Windows.Forms.Label label_newSeed2;
        private System.Windows.Forms.Label label_newSeed1;
        private System.Windows.Forms.Label label_yourTotal;
        private System.Windows.Forms.Label label_dealerTotal;
        private System.Windows.Forms.TextBox textBox_newBet;
        private System.Windows.Forms.Label label_yourTotal2;
        private System.Windows.Forms.Label label_dealer2;
        private System.Windows.Forms.Button button_newBet;
        private System.Windows.Forms.PictureBox pictureBox_Rat;
        private System.Windows.Forms.Label label_winLoseDraw;
    }
}