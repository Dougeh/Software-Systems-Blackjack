﻿//Douglas Wilklow
//Software Systems Development, Fall 2021 - Prof. Jeanty
//Form_Blackjack.cs
//For details, check the comments starting at line 17.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace SofSys_Project_2
{
    /// <summary>
    /// Form_Blackjack
    /// The Blackjack form!  This opens each time you press the "Start Game/New Player" button in the main menu.
    /// From the main menu, you can change the values for # of decks, starting cash, and the seed, and even H17/S17.
    /// If you hit the "Start Game/New Player" button again, it'll open a new Blackjack form with those new values.
    /// You can still play on the old window as well, no problem.
    /// </summary>
    public partial class Form_Blackjack : Form
    {
        public int cash;
        public static int seed;
        public static int numdecks;
        public bool local_H17;
        aShoe shoe;
        List<Control> deletables = new List<Control>();
        List<aCard> your_hand = new List<aCard>();
        List<aCard> dealer_hand = new List<aCard>();
        int your_total = 0;
        int dealer_total = 0;
        int your_bet = 0;
        bool your_ace = false;
        bool dealer_ace = false;

        public Form_Blackjack()
        {
            cash = Form_Interview.main_cash;
            seed = Form_Interview.main_seed;
            numdecks = Form_Interview.main_numdecks;
            local_H17 = Form_Interview.H17;
            shoe = new aShoe();
            InitializeComponent();
        }

        private void Form_Blackjack_Load(object sender, EventArgs e)
        {
            DealerSays("Hey, welcome to my Blackjack table.  \nHave a seat, and place a bet so we can get started, here.");
            label_cash.Text = "Total $ remaining:  " + cash.ToString(); //Simply updating the total $ and having the dealer greet the player
        }

        private void button_hit_Click(object sender, EventArgs e)
        {
            IDrawCard cardinterface = shoe;
            aCard card = cardinterface.Draw();
            your_hand.Add(card);
            UpdateCards(); //Updates card images, values, etc.  Disables hit/stand buttons on bust.
            if (your_total >= 21)
                TakeTurn();
        }

        private void button_reset_Click(object sender, EventArgs e)
        {
            if (this.textBox_resetSeed.Text == "")
            {
                DealerSays("You're gonna have to actually type in a seed in order to cheat.");
                return;
            }
            pictureBox_Rat.Image = SofSys_Project_2.Properties.Resources.Rat;
            pictureBox_Rat.Visible = true;
            pictureBox_Rat.SendToBack();
            DealerSays("Oh, how'd that dirty stinkin' rat get there?  Oh, well.  \nThe deck's been totally rebuilt.  Shenanigans.");
            int x; //Same int parse I use everywhere else
            bool is_num = int.TryParse(this.textBox_resetSeed.Text, out x); //Makes sure that it's an integer
            if (is_num)
                seed = x;
            shoe = new aShoe(); //Re-fills and re-shuffles the deck(or decks) with the new seed
        }

        private void textBox_resetSeed_TextChanged(object sender, EventArgs e)
        {
            int x;
            bool is_num = int.TryParse(this.textBox_resetSeed.Text, out x); //Makes sure that it's an integer
            if (is_num)
                seed = x;
            aShoe shoe = new aShoe();
        }

        private void textBox_resetSeed_Click(object sender, EventArgs e)
        {   //Calls the user a cheater for re-shuffling the deck when they feel their luck is down
            if (textBox_resetSeed.Enabled)
                DealerSays("Hey!  You tryin' to cheat?  \nGo on ahead, see if it improves your chances.  Heh.");
        }

        /// <summary>
        /// Makes the dealer talk.  Any string passed into the "blabber" argument is spit out to the label in the center of the game screen.
        /// </summary>
        /// <param name="blabber"></param>
        void DealerSays(string blabber)
        {
            this.label_blabber.Text = blabber;
        }

        /// <summary>
        /// Once all users have finished betting, meaning they've either busted or chosen to stand, the end of the game is processed.
        /// The dealer will hit until they draw 17 or higher, where H17 dealers will hit and S17 dealers will stand.
        /// Once this is done, all hands are compared and a winner is chosen.  (That's the hard part)
        /// </summary>
        void TakeTurn()
        {
            //Turning off the user's buttons
            button_hit.Enabled = false;
            button_stand.Enabled = false;

            //Initializing a lil' card
            IDrawCard cardinterface = shoe;
            aCard card = cardinterface.Draw();
            bool winflag = false;
            label_winLoseDraw.Text = "LOSE (-$" + (your_bet).ToString() + ")"; //Default lose condition, win flag changes this

            //Dealer draws until 17+
            while (dealer_total < 17)
            {
                card = cardinterface.Draw();
                dealer_hand.Add(card);
                UpdateCards();
                Thread.Sleep(300); //Pauses the window between draws to make drawing feel better
            }

            //If 17 exactly, process H17/S17 action
            if (dealer_total == 17)
            {
                if (local_H17 == true)  //if they're playing Hit 17
                {
                    card = cardinterface.Draw();
                    dealer_hand.Add(card);
                    UpdateCards();
                    Thread.Sleep(300); //Same as above, pauses the window for better game-feel
                }
                //If they're playing Soft 17, dealer does nothing/stands
            }

            //Game over, decide who (if anyone) wins
                //If dealer busts during their draw phase, everyone else (who hasn't busted) wins
            //Forest of win conditions, winflag defaults to false so I don't need to set it for every loss condition
            int bj_win = 0;
            if (your_total > 21)
            {   //If the player busts
                string thing = "Ah, you busted.  Tough luck, kid.\n";
                if (dealer_total > 21)  //If the dealer's also busted
                {
                    cash += your_bet;
                    label_winLoseDraw.Text = "DRAW (+$0)";
                    thing += "Looks like we both busted, actually.  Good game.";
                }
                if (dealer_total == 21) //If the dealer's got 21
                {
                    Thread.Sleep(500); //Pause for reading
                    thing += "Hey lookie here though, I've got 21!  Heh.";
                }
                DealerSays(thing); //The dealer will say some combo of the three above lose conditions for player busts.
                winflag = false;
            }
            else
            {
                if (dealer_total > 21 && your_total < 21)   //If the dealer busts and the player doesn't
                {
                    winflag = true;
                    DealerSays("Hey, I lost this time!  \nYou win, kid.  Here's your payout.");
                }
                if (your_total == 21)   //If the player's sitting at a total of 21 exactly
                {  
                    if (your_ace && !dealer_ace)//If the user's got Blackjack, and the dealer doesn't (an ace and a 10 of some sort)
                    {
                        winflag = true;
                        if (your_hand.Count > 2)
                            DealerSays("21, looks like that ace was lucky.\nCongrats, here's your winnings.");
                        else
                        {
                            DealerSays("Hey nice, you got Blackjack.\nCongrats on the win, and the 3:2 payout.");
                            bj_win = your_bet / 2 + your_bet % 2;
                        }
                    }
                    else if (your_ace && dealer_ace && your_total == 21 && dealer_total == 21 && your_hand.Count == 2) //If both the user and the dealer have Blackjack
                    {   //Test case:  7 decks, Seed = 1, hit until bust on first hand.  Should show up in second hand
                        cash += your_bet; //The hands tied, so the player gets their bet back
                        label_winLoseDraw.Text = "DRAW (+$0)";
                        DealerSays("Hah!  Double blackjack.  You almost had me, there.");
                    }
                    else if (dealer_total == 21) //If neither the user nor dealer have blackjack, but tie at 21
                    {
                        cash += your_bet; //This is a tie, so the player gets their bet back
                        label_winLoseDraw.Text = "DRAW (+$0)";
                        DealerSays("How'd we both wind up at 21?\nOh well, guess we tied.  Good round.");
                    }
                    else if (dealer_total < 21 && your_ace) //If the dealer's got less than 21 and you've got blackjack
                    {
                        winflag = true;
                        if (your_hand.Count > 2)
                            DealerSays("21, looks like that ace was lucky.\nCongrats, here's your winnings.");
                        else
                        {
                            DealerSays("Hey, nice, you got Blackjack!\nCongrats, here's your winnings plus the blackjack bonus.");
                            bj_win = your_bet / 2 + your_bet % 2;
                        }
                    }
                    else if (dealer_total < 21 || dealer_total > 21) //Pretty rare case!  Took a lot of testing to even run into this one.  Player hand is 21, higher than the dealer's, and neither one has aces.
                    {
                        winflag = true;
                        DealerSays("21 on the nose, and with no Aces!  That's a good hand, congrats on the win.");
                    }
                }
                else if (dealer_total == 21)    //if the dealer's at 21 exactly
                {
                    if (dealer_ace && dealer_hand.Count == 2) //if the dealer's got Blackjack
                    {
                        DealerSays("Hey kid, Blackjack.  Not what you wanted to see?");
                    }
                    else        //If the dealer's got 21 without it being a blackjack
                    {
                        DealerSays("Hey, look at that, I got 21.  \nTough break, kid.  I win this time.");
                    }
                }
                else if (dealer_total < 21)     //If the dealer hand is below 21
                {
                    if (your_total > dealer_total)  //If the player's hand is bigger than the dealer's
                    {
                        DealerSays("You got me on this one, well played.");
                        winflag = true;
                    }
                    else if (your_total == dealer_total)    //If the player's hand and the dealer's hand tie
                    {
                        cash += your_bet;   //Give the player back their bet
                        label_winLoseDraw.Text = "DRAW (+$0)";
                        DealerSays("It's a push, no one wins.  Here's your bet back.");
                    }
                    else if (your_total < dealer_total) //If the player's got a smaller hand than the dealer
                    {
                        DealerSays("Ah, dealer wins.  \nThanks for your generosity, you love to see it.");
                    }
                }
            }
            //Empty both hands
            while (your_hand.Count > 0)
                your_hand.RemoveAt(0);
            while (dealer_hand.Count > 0)
                dealer_hand.RemoveAt(0);
            your_ace = false;
            dealer_ace = false;
            //I decided to avoid calling UpdateCards() here because it'd just blank out all the cards before the user could see them

            //Re-add the newBet button control
            textBox_newBet.Enabled = true;
            textBox_newBet.Text = "";
            this.Controls.Add(button_newBet);
            button_newBet.BringToFront();

            //add winning bet amount to total $ if they won
            if (winflag)
            {
                //int odd = 0;
                //if (your_bet % 2 != 0)
                //    odd = 1; //Rounds up on odd bets because this is a generous casino :^)
                label_winLoseDraw.Text = "WIN (+$" + ((int)(your_bet * 2) + bj_win).ToString() + ")";
                cash += (int)(your_bet * 2 + bj_win);
            }
            label_cash.Text = "Total $ remaining:  " + cash.ToString();
            if (cash <= 0)
            {
                Thread.Sleep(500);
                DealerSays("What a shame, you're out of cash.  Moolah.  Dough.  Dollary-doos.  Smackaroons.  Not my problem.  Get lost, kid.  Table's closed.");
                textBox_newBet.Enabled = false;
                textBox_resetSeed.Enabled = false;
                button_reset.Enabled = false;
                button_newBet.Enabled = false;
            }
            label_winLoseDraw.Visible = true;
            this.ActiveControl = textBox_newBet;
            return;
        }

        /// <summary>
        /// BEEFY BOY
        /// This chonker is for updating the pictures of cards based on what the player and the dealer have in their hands.
        /// It also counts totals for each hand, and displays this value accordingly.
        /// </summary>
        void UpdateCards()
        {
            your_total = 0;
            dealer_total = 0;

            //Include part that updates the count above your hand
            while (deletables.Count > 0)
            {   //This loop deletes all the card images each time they update, so they can be placed anew!  Took a while to come up with this.
                this.Controls.Remove(deletables[0]);
                deletables.RemoveAt(0);
            }

            //This mess is how I'm dynamically spacing the cards out as they're drawn.
            int buffer = 5;
            int cardspacer = 100 + buffer;
            int startpoint = 0;
            if (this.Width <= your_hand.Count * 100)
            {
                buffer = 0;
                cardspacer = this.Width / your_hand.Count;
            }
            else
            {
                startpoint = this.Width / 2 - (cardspacer * your_hand.Count / 2);
            }

            //Loop for the user's hand
            for (int i = 0; i < your_hand.Count; i++)
            {



                //Declaring and initializing a PictureBox to put into the form
                //Yoinked these five lines of code from 
                //https://stackoverflow.com/questions/31879906/add-picturebox-to-form-at-runtime
                var cardimg = new PictureBox
                {
                    Name = "pictureBox",
                    Size = new Size(100, 145),
                    Location = new Point(startpoint + cardspacer * i, 285),
                    SizeMode = PictureBoxSizeMode.StretchImage
                };


                //GIANT SWITCH STATEMENT FOR THE CARD IMAGES
                //52 possibilities!  Fun!
                Suit value1 = your_hand[i].suit;
                int value2 = your_hand[i].value;

                //Setting the player's ace flag (See "Calculating Aces" comments for details
                if (value2 == 1)
                    your_ace = true;

                //May as well calculate total hand size here amirite
                if (value2 > 10)
                    your_total += 10;
                else
                    your_total += value2;

                switch (value1)
                {
                    case Suit.SPADES:
                        {
                            switch (value2)
                            {   //Big ol' switch statement to map the spades-suited card images to the right values
                                case 1:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ace_of_spades;
                                    break;
                                case 2:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.two_of_spades;
                                    break;
                                case 3:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.three_of_spades;
                                    break;
                                case 4:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.four_of_spades;
                                    break;
                                case 5:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.five_of_spades;
                                    break;
                                case 6:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.six_of_spades;
                                    break;
                                case 7:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.seven_of_spades;
                                    break;
                                case 8:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.eight_of_spades;
                                    break;
                                case 9:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.nine_of_spades;
                                    break;
                                case 10:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ten_of_spades;
                                    break;
                                case 11:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.king_of_spades2;
                                    break;
                                case 12:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.queen_of_spades2;
                                    break;
                                case 13:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.jack_of_spades2;
                                    break;
                            }
                            break;
                        }
                    case Suit.HEARTS:
                        {
                            switch (value2)
                            {   //Big ol' switch statement to map the hearts-suited card images to the right values
                                case 1:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ace_of_hearts;
                                    break;
                                case 2:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.two_of_hearts;
                                    break;
                                case 3:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.three_of_hearts;
                                    break;
                                case 4:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.four_of_hearts;
                                    break;
                                case 5:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.five_of_hearts;
                                    break;
                                case 6:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.six_of_hearts;
                                    break;
                                case 7:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.seven_of_hearts;
                                    break;
                                case 8:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.eight_of_hearts;
                                    break;
                                case 9:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.nine_of_hearts;
                                    break;
                                case 10:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ten_of_hearts;
                                    break;
                                case 11:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.king_of_hearts2;
                                    break;
                                case 12:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.queen_of_hearts2;
                                    break;
                                case 13:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.jack_of_hearts2;
                                    break;
                            }
                            break;
                        }
                    case Suit.DIAMONDS:
                        {
                            switch (value2)
                            {   //Big ol' switch statement to map the diamonds-suited card images to the right values
                                case 1:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ace_of_diamonds;
                                    break;
                                case 2:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.two_of_diamonds;
                                    break;
                                case 3:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.three_of_diamonds;
                                    break;
                                case 4:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.four_of_diamonds;
                                    break;
                                case 5:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.five_of_diamonds;
                                    break;
                                case 6:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.six_of_diamonds;
                                    break;
                                case 7:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.seven_of_diamonds;
                                    break;
                                case 8:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.eight_of_diamonds;
                                    break;
                                case 9:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.nine_of_diamonds;
                                    break;
                                case 10:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ten_of_diamonds;
                                    break;
                                case 11:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.king_of_diamonds2;
                                    break;
                                case 12:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.queen_of_diamonds2;
                                    break;
                                case 13:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.jack_of_diamonds2;
                                    break;
                            }
                            break;
                        }
                    case Suit.CLUBS:
                        {
                            switch (value2)
                            {   //Big ol' switch statement to map the clubs-suited card images to the right values
                                case 1:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ace_of_clubs;
                                    break;
                                case 2:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.two_of_clubs;
                                    break;
                                case 3:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.three_of_clubs;
                                    break;
                                case 4:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.four_of_clubs;
                                    break;
                                case 5:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.five_of_clubs;
                                    break;
                                case 6:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.six_of_clubs;
                                    break;
                                case 7:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.seven_of_clubs;
                                    break;
                                case 8:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.eight_of_clubs;
                                    break;
                                case 9:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.nine_of_clubs;
                                    break;
                                case 10:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ten_of_clubs;
                                    break;
                                case 11:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.king_of_clubs2;
                                    break;
                                case 12:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.queen_of_clubs2;
                                    break;
                                case 13:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.jack_of_clubs2;
                                    break;
                            }
                            break;
                        }
                }
                this.Controls.Add(cardimg); //Displaying the Picturebox that was generated
                deletables.Add(cardimg);    //Adding the card to a list of things to wipe at the start of next time
            }


            buffer = 5;
            cardspacer = 100 + buffer;
            startpoint = 0;
            if (this.Width <= dealer_hand.Count * 100)
            {
                buffer = 0;
                cardspacer = this.Width / dealer_hand.Count;
            }
            else
            {
                startpoint = this.Width / 2 - (cardspacer * dealer_hand.Count / 2);
            }

            //Loop for the dealer's hand
            for (int i = 0; i < dealer_hand.Count; i++)
            {
                //Declaring and initializing a PictureBox to put into the form
                //Yoinked these five lines of code from 
                //https://stackoverflow.com/questions/31879906/add-picturebox-to-form-at-runtime
                var cardimg = new PictureBox
                {
                    Name = "pictureBox",
                    Size = new Size(100, 145),
                    Location = new Point(startpoint + cardspacer * i, 12), //Puts it at the top of the page, growing from the center
                    SizeMode = PictureBoxSizeMode.StretchImage
                };


                //GIANT SWITCH STATEMENT FOR THE CARD IMAGES
                //52 possibilities!  Fun!
                Suit value1 = dealer_hand[i].suit;
                int value2 = dealer_hand[i].value;

                //Setting the dealer's ace flag (See "Calculating Aces" comments for details
                if (value2 == 1)
                    dealer_ace = true;

                //Calculating the dealer's hand total too
                if (value2 > 10)
                    dealer_total += 10;
                else
                    dealer_total += value2;

                switch (value1)
                {
                    case Suit.SPADES:
                        {
                            switch (value2)
                            {   //Big ol' switch statement to map the spades-suited card images to the right values
                                case 1:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ace_of_spades;
                                    break;
                                case 2:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.two_of_spades;
                                    break;
                                case 3:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.three_of_spades;
                                    break;
                                case 4:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.four_of_spades;
                                    break;
                                case 5:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.five_of_spades;
                                    break;
                                case 6:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.six_of_spades;
                                    break;
                                case 7:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.seven_of_spades;
                                    break;
                                case 8:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.eight_of_spades;
                                    break;
                                case 9:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.nine_of_spades;
                                    break;
                                case 10:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ten_of_spades;
                                    break;
                                case 11:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.king_of_spades2;
                                    break;
                                case 12:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.queen_of_spades2;
                                    break;
                                case 13:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.jack_of_spades2;
                                    break;
                            }
                            break;
                        }
                    case Suit.HEARTS:
                        {
                            switch (value2)
                            {   //Big ol' switch statement to map the hearts-suited card images to the right values
                                case 1:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ace_of_hearts;
                                    break;
                                case 2:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.two_of_hearts;
                                    break;
                                case 3:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.three_of_hearts;
                                    break;
                                case 4:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.four_of_hearts;
                                    break;
                                case 5:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.five_of_hearts;
                                    break;
                                case 6:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.six_of_hearts;
                                    break;
                                case 7:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.seven_of_hearts;
                                    break;
                                case 8:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.eight_of_hearts;
                                    break;
                                case 9:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.nine_of_hearts;
                                    break;
                                case 10:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ten_of_hearts;
                                    break;
                                case 11:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.king_of_hearts2;
                                    break;
                                case 12:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.queen_of_hearts2;
                                    break;
                                case 13:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.jack_of_hearts2;
                                    break;
                            }
                            break;
                        }
                    case Suit.DIAMONDS:
                        {
                            switch (value2)
                            {   //Big ol' switch statement to map the diamonds-suited card images to the right values
                                case 1:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ace_of_diamonds;
                                    break;
                                case 2:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.two_of_diamonds;
                                    break;
                                case 3:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.three_of_diamonds;
                                    break;
                                case 4:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.four_of_diamonds;
                                    break;
                                case 5:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.five_of_diamonds;
                                    break;
                                case 6:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.six_of_diamonds;
                                    break;
                                case 7:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.seven_of_diamonds;
                                    break;
                                case 8:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.eight_of_diamonds;
                                    break;
                                case 9:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.nine_of_diamonds;
                                    break;
                                case 10:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ten_of_diamonds;
                                    break;
                                case 11:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.king_of_diamonds2;
                                    break;
                                case 12:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.queen_of_diamonds2;
                                    break;
                                case 13:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.jack_of_diamonds2;
                                    break;
                            }
                            break;
                        }
                    case Suit.CLUBS:
                        {
                            switch (value2)
                            {   //Big ol' switch statement to map the clubs-suited card images to the right values
                                case 1:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ace_of_clubs;
                                    break;
                                case 2:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.two_of_clubs;
                                    break;
                                case 3:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.three_of_clubs;
                                    break;
                                case 4:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.four_of_clubs;
                                    break;
                                case 5:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.five_of_clubs;
                                    break;
                                case 6:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.six_of_clubs;
                                    break;
                                case 7:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.seven_of_clubs;
                                    break;
                                case 8:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.eight_of_clubs;
                                    break;
                                case 9:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.nine_of_clubs;
                                    break;
                                case 10:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.ten_of_clubs;
                                    break;
                                case 11:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.king_of_clubs2;
                                    break;
                                case 12:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.queen_of_clubs2;
                                    break;
                                case 13:
                                    cardimg.Image = SofSys_Project_2.Properties.Resources.jack_of_clubs2;
                                    break;
                            }
                            break;
                        }
                }
                this.Controls.Add(cardimg);
                deletables.Add(cardimg);
            }

            //Calculating aces:
            //If there's at least one ace in a hand, the ace flag is set.
            //This flag adds 10 to the value of a hand as long as that wouldn't put it above 21.
            //In the event of the ace putting the hand above 21, all aces in the hand are instead counted as 1.
            string dealer_label = "";
            string your_label = "";
            if (your_ace)
            {
                if (your_total + 10 <= 21)
                {
                    your_total += 10;
                    your_label = (your_total - 10).ToString() + "(High Ace: " + your_total.ToString() + ")";
                }
                else
                    your_label = your_total.ToString();
            }
            else
                your_label = your_total.ToString();
            if (dealer_ace)
            {
                if (dealer_total + 10 <= 21)
                {
                    dealer_total += 10;
                    dealer_label = (dealer_total - 10).ToString() + "(High Ace: " + dealer_total.ToString() + ")";
                }
                else
                    dealer_label = dealer_total.ToString();
            }
            else
                dealer_label = dealer_total.ToString();
            //Displaying the dealer total to its label
            //if (dealer_ace && dealer_total <= 21) //Displaying the value of the hand with low aces, and high aces in parentheses
            //    dealer_label = (dealer_total - 10).ToString() + "(High Ace: " + dealer_total.ToString() + ")";
            //else
            //    dealer_label = dealer_total.ToString();
            if (dealer_total > 21)
                label_dealerTotal.Text = "BUSTED (" + dealer_total.ToString() + ")";
            else
                label_dealerTotal.Text = dealer_label;

            //Displaying the player's total to their label
            //if (your_ace && your_total <= 21) //Displaying the value of the hand with low aces, and high aces in parentheses
            //    your_label = (your_total - 10).ToString() + "(High Ace: " + your_total.ToString() + ")";
            //else
            //    your_label = your_total.ToString();
            if (your_total > 21)
                label_yourTotal.Text = "BUSTED (" + your_total.ToString() + ")";
            else
                label_yourTotal.Text = your_label;
            Refresh();
        }

        private void button_stand_Click(object sender, EventArgs e)
        {
            //The player's done getting cards, so process the end of this round
            TakeTurn();
        }

        private void button_newBet_Click(object sender, EventArgs e)
        {
            if (this.textBox_newBet.Text == "")
            {       //If the user didn't input a bet before pressing the "New Bet" button
                DealerSays("You new here?  I know it's scary, buddy, but you have to enter an amount to bet, okay?");
                this.ActiveControl = textBox_newBet;
                return;
            }
            int x; //Grabbing your bet with the usual parse
            bool is_num = int.TryParse(this.textBox_newBet.Text, out x); //Makes sure that it's an integer
            if (is_num)
                your_bet = x;
            else
            {   //possible DealerSays prompt here
                DealerSays("Alright, pal.  We only accept integer values as currency here.  \nIf you're gonna bring chars and doubles to my table, I'm gonna call security.");
                this.ActiveControl = textBox_newBet;
                return;
            }

            //Checking to see if you have enough money left for this bet
            if (your_bet <= cash)
                cash -= your_bet;
            else
            {   //If the user doesn't have enough dough
                DealerSays("You don't have enough cash to make that kind of bet.  \nHow do I know?  Let's say I can smell it on ya.");
                this.ActiveControl = textBox_newBet;
                return;
            }

            DealerSays("Here's your cards.");

            //Making the dealer/player hand value labels visible
            label_winLoseDraw.Visible = false;
            label_dealerTotal.Visible = true;
            label_dealer2.Visible = true;
            label_yourTotal.Visible = true;
            label_yourTotal2.Visible = true;

            //Updating the remaining cash label
            label_cash.Text = "Total $ remaining:  " + cash.ToString();

            //Drawing the user's first two cards
            IDrawCard cardinterface = shoe; //Card 1
            aCard card = cardinterface.Draw();
            your_hand.Add(card);
            UpdateCards();
            Thread.Sleep(300); //Short pause for better game-feel

            card = cardinterface.Draw();    //Card 2
            your_hand.Add(card);
            UpdateCards();
            Thread.Sleep(300);


            //Drawing the dealer's first card
            card = cardinterface.Draw();
            dealer_hand.Add(card);
            UpdateCards();


            //Enabling the buttons for gameplay
            textBox_newBet.Enabled = false;
            this.Controls.Remove(button_newBet);
            button_hit.Enabled = true;
            button_stand.Enabled = true;
        }
    }
}
//That's a lotta lines