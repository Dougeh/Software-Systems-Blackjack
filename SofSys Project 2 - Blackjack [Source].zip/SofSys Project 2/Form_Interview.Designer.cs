﻿//Douglas Wilklow
//Software Systems Development - Fall 2021
//Prof. Jeanty
//Form_Interview.cs, named as such due to a discussion we had in class,
//  where Prof. specifically mentioned that he wanted the main form of
//  the application to be named "Form_Interview"
//I will be explaining my code ad nauseum to avoid any confusion in the grading process.

namespace SofSys_Project_2
{
    partial class Form_Interview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_title = new System.Windows.Forms.Label();
            this.label_decks = new System.Windows.Forms.Label();
            this.label_seed = new System.Windows.Forms.Label();
            this.radioButton_H17 = new System.Windows.Forms.RadioButton();
            this.radioButton_S17 = new System.Windows.Forms.RadioButton();
            this.button_start = new System.Windows.Forms.Button();
            this.textBox_seed = new System.Windows.Forms.TextBox();
            this.label_available = new System.Windows.Forms.Label();
            this.textBox_available = new System.Windows.Forms.TextBox();
            this.comboBox_decks = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label_title
            // 
            this.label_title.AutoSize = true;
            this.label_title.Location = new System.Drawing.Point(31, 14);
            this.label_title.Name = "label_title";
            this.label_title.Size = new System.Drawing.Size(363, 15);
            this.label_title.TabIndex = 0;
            this.label_title.Text = "It\'s Doug Wilklow\'s Blackjack baybeeeee get in here let\'s play c\'mon";
            // 
            // label_decks
            // 
            this.label_decks.AutoSize = true;
            this.label_decks.Location = new System.Drawing.Point(20, 79);
            this.label_decks.Name = "label_decks";
            this.label_decks.Size = new System.Drawing.Size(100, 15);
            this.label_decks.TabIndex = 1;
            this.label_decks.Text = "# of Decks to use:";
            // 
            // label_seed
            // 
            this.label_seed.AutoSize = true;
            this.label_seed.Location = new System.Drawing.Point(85, 109);
            this.label_seed.Name = "label_seed";
            this.label_seed.Size = new System.Drawing.Size(35, 15);
            this.label_seed.TabIndex = 2;
            this.label_seed.Text = "Seed:";
            // 
            // radioButton_H17
            // 
            this.radioButton_H17.AutoSize = true;
            this.radioButton_H17.Location = new System.Drawing.Point(216, 65);
            this.radioButton_H17.Name = "radioButton_H17";
            this.radioButton_H17.Size = new System.Drawing.Size(56, 19);
            this.radioButton_H17.TabIndex = 5;
            this.radioButton_H17.TabStop = true;
            this.radioButton_H17.Text = "Hit 17";
            this.radioButton_H17.UseVisualStyleBackColor = true;
            this.radioButton_H17.CheckedChanged += new System.EventHandler(this.radioButton_H17_CheckedChanged);
            // 
            // radioButton_S17
            // 
            this.radioButton_S17.AutoSize = true;
            this.radioButton_S17.Location = new System.Drawing.Point(216, 90);
            this.radioButton_S17.Name = "radioButton_S17";
            this.radioButton_S17.Size = new System.Drawing.Size(61, 19);
            this.radioButton_S17.TabIndex = 6;
            this.radioButton_S17.TabStop = true;
            this.radioButton_S17.Text = "Soft 17";
            this.radioButton_S17.UseVisualStyleBackColor = true;
            this.radioButton_S17.CheckedChanged += new System.EventHandler(this.radioButton_S17_CheckedChanged);
            // 
            // button_start
            // 
            this.button_start.Location = new System.Drawing.Point(303, 40);
            this.button_start.Name = "button_start";
            this.button_start.Size = new System.Drawing.Size(90, 87);
            this.button_start.TabIndex = 7;
            this.button_start.Text = "Start Game / New Player";
            this.button_start.UseVisualStyleBackColor = true;
            this.button_start.Click += new System.EventHandler(this.button_start_Click);
            // 
            // textBox_seed
            // 
            this.textBox_seed.Location = new System.Drawing.Point(118, 104);
            this.textBox_seed.Name = "textBox_seed";
            this.textBox_seed.Size = new System.Drawing.Size(67, 23);
            this.textBox_seed.TabIndex = 9;
            this.textBox_seed.TextChanged += new System.EventHandler(this.textBox_seed_TextChanged);
            // 
            // label_available
            // 
            this.label_available.AutoSize = true;
            this.label_available.Location = new System.Drawing.Point(56, 47);
            this.label_available.Name = "label_available";
            this.label_available.Size = new System.Drawing.Size(64, 15);
            this.label_available.TabIndex = 10;
            this.label_available.Text = "Available $";
            // 
            // textBox_available
            // 
            this.textBox_available.Location = new System.Drawing.Point(118, 40);
            this.textBox_available.Name = "textBox_available";
            this.textBox_available.Size = new System.Drawing.Size(67, 23);
            this.textBox_available.TabIndex = 11;
            this.textBox_available.Text = "100";
            this.textBox_available.TextChanged += new System.EventHandler(this.textBox_available_TextChanged);
            // 
            // comboBox_decks
            // 
            this.comboBox_decks.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_decks.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox_decks.FormattingEnabled = true;
            this.comboBox_decks.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8"});
            this.comboBox_decks.Location = new System.Drawing.Point(118, 71);
            this.comboBox_decks.Name = "comboBox_decks";
            this.comboBox_decks.Size = new System.Drawing.Size(66, 23);
            this.comboBox_decks.TabIndex = 12;
            this.comboBox_decks.SelectedIndexChanged += new System.EventHandler(this.comboBox_decks_SelectedIndexChanged);
            // 
            // Form_Interview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 137);
            this.Controls.Add(this.comboBox_decks);
            this.Controls.Add(this.textBox_available);
            this.Controls.Add(this.label_available);
            this.Controls.Add(this.textBox_seed);
            this.Controls.Add(this.button_start);
            this.Controls.Add(this.radioButton_S17);
            this.Controls.Add(this.radioButton_H17);
            this.Controls.Add(this.label_seed);
            this.Controls.Add(this.label_decks);
            this.Controls.Add(this.label_title);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Form_Interview";
            this.Text = "Blackjack! - Main Menu";
            this.Load += new System.EventHandler(this.Form_Interview_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_title;
        private System.Windows.Forms.Label label_decks;
        private System.Windows.Forms.Label label_seed;
        private System.Windows.Forms.RadioButton radioButton_H17;
        private System.Windows.Forms.RadioButton radioButton_S17;
        private System.Windows.Forms.Button button_start;
        private System.Windows.Forms.TextBox textBox_seed;
        private System.Windows.Forms.Label label_available;
        private System.Windows.Forms.TextBox textBox_available;
        private System.Windows.Forms.ComboBox comboBox_decks;
    }
}