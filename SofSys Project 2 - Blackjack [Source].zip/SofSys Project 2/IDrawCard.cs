﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SofSys_Project_2
{
    /// <summary>
    /// a frickin' interface for drawin' cards.
    /// It specifies that anything branching from it must implement the function "Draw" with the return type of aCard.
    /// </summary>
    interface IDrawCard
    {
        aCard Draw();
    }
}
