﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SofSys_Project_2
{
    /// <summary>
    /// Class aDeckOfCards, meant to represent a deck of cards.
    /// will automatically shuffle the cards upon construction, holding the shuffled deck in a List<aCard> named "deck"
    /// </summary>
    public class aDeckOfCards : aRandomVariable
    {
        public List<aCard> shuffled = new List<aCard>();

        /// <summary>
        /// Constructor for the aDeckofCards class.  Creates a list of every card, then empties it randomly into a shuffled deck.
        /// Can do this with multiple decks at once, where it generates the list multiple times then shuffles it into one big mega-deck.
        /// </summary>
        /// <param name="s"></param>
        /// int s, the seed for the random number generator.
        /// <param name="decks"></param>
        /// int decks, the number of decks being shuffled.
        public aDeckOfCards(int s, int decks)
        {
            //Any random number generators formed with this line will follow a single order shared between all decks.
            rando = new Random(s);

            //Generate a random deck of cards, or many if decks > 1
            //This makes a full list of every card one by one, then shuffles it.  This shuffled deck is what ashoe uses.
            
            //Part 1:  Making the (Not random) list of cards
            List<aCard> cards = new List<aCard>();

            Suit[] soot = new Suit[4] { Suit.SPADES, Suit.HEARTS, Suit.DIAMONDS, Suit.CLUBS };
            for (int d = 0; d < decks; d++)
            {   //This outer loop will iterate once for every deck that the user wants to include in their shuffle.
                for (int i = 0; i < 4; i++)
                {   //Incrementing i here moves between suits using the above array
                    for (int j = 1; j <= 13; j++)
                        cards.Add(new aCard(soot[i], j));
                }
            }

            //Emptying the List "cards" into a shuffled List "deck" while deleting the un-shuffled List
            
            while (cards.Count > 0)
            {   //This loop runs until cards is empty.
                int x = rando.Next(cards.Count);
                shuffled.Add(cards[x]); //Adding a random card to deck
                cards.RemoveAt(x); //removing the selected card from the cards List
            }
        }
    }
}
