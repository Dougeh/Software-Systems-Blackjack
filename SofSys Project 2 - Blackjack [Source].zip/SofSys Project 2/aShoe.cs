﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SofSys_Project_2
{
    /// <summary>
    /// aShoe, a class representing a "Shoe," which is a card-drawing mechanism used in casinos.
    /// Takes in one or multiple decks, 
    /// </summary>
    public class aShoe : IDrawCard
    {
        aDeckOfCards allcards = new aDeckOfCards(Form_Blackjack.seed, Form_Blackjack.numdecks);
        aCard IDrawCard.Draw()
        {
            allcards.shuffled.RemoveAt(0);
            if (allcards.shuffled.Count == 0)   //If the deck is empty (Rare!  Happens, though)
                allcards = new aDeckOfCards(Form_Blackjack.seed, Form_Blackjack.numdecks);
            aCard card = allcards.shuffled[0];
            return card;
        }
    }
}
